import React, { Component } from 'react';
import logo from '../logo.svg';
import '../styles/App.css';

class LoginComponent extends Component {
  render() {
    return (
      <div className="app-login">
          
          
      </div>
    );
  }
}

export default LoginComponent;
