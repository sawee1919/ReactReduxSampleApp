import React, { Component } from 'react';
import '../styles/App.css';
// import { BrowserRouter, Route, Link, IndexRoute, hashHistory, browserHistory } from 'react-router';
import { BrowserRouter, Route } from 'react-router-dom';
import Header from '../containers/Header';
import Footer from '../containers/Footer';
import Login from '../containers/Login';

class App extends Component {
    constructor(props){
        super(props);

        props.loadThings();
    }
    componentDidMount(){
        
    }
  render() {
    console.log(this.props.thingsReceived.toJS());
    
    return (
        <div className="main-app">
            <Header />
            <BrowserRouter>
                <Route exact path="/" component={Login} />
            </BrowserRouter>
            <Footer /> 
        </div>
    );
  }
}

export default App;
