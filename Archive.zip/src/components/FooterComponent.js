import React, { Component } from 'react';
import logo from '../logo.svg';
import '../styles/App.css';

class FooterComponent extends Component {
  render() {
    return (
      <div className="app-footer">
          Footer 
      </div>
    );
  }
}

export default FooterComponent;
