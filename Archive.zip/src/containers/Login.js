import LoginComponent from '../components/LoginComponent';
import { connect } from 'react-redux';
// import { simpleAction } from '../actions/index';

const mapStateToProps = state => ({
  ...state
 })

 const mapDispatchToProps = dispatch => ({
  // simpleAction: () => dispatch(simpleAction())
 })

 const Login = connect(mapStateToProps, mapDispatchToProps)(LoginComponent);
 export default Login;