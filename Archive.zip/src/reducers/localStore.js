import { fromJS } from "immutable";

const initialState = fromJS({
    "posts" : []
});

export default function localStore(state = initialState, action){
    switch (action.type) {
        case "LOAD_PROJECT":
        console.log("Get the data to the actions", action);
        return state;

        case "THINGS_RECEIVED":
        console.log("State", action);
        state = state.setIn(['posts'], action.json);
        console.log("State", state.toJS());
        return state;

        default:
        return state;
    }
}
