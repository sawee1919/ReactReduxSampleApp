import React, { Component } from 'react';
import logo from '../logo.svg';
import '../styles/App.css';

class HeaderComponent extends Component {
  render() {
    return (
      <div className="app-header">
          Sample Application
      </div>
    );
  }
}

export default HeaderComponent;
